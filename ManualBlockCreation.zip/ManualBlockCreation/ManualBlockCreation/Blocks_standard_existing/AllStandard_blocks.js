console.log('动态制作加载新的积木')

function ss_blockly_inject(Blockly) {
    console.log('开给 blockly 注入新积木属性')


    /*****************************************************************************************************************************************/
    /***************************************************** Begin of Injecting New Blocks *****************************************************/
    /************** To enable previewing the standard blocks */
    /*****************************************************************************************************************************************/


    Blockly.defineBlocksWithJsonArray([{
        type: "ss_get_net_handle", // re-name the origianl block: ss_prim3_get_net_handle
        message0: "%{BKY_SS_BLOCK_GET_NET_HANDLE}",
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }]);

    /*** Blockly Python **/
    Blockly.Python['ss_get_net_handle'] = function (block) {
        var order = Blockly.Python.ORDER_ATOMIC;
        var code = Blockly.Python.format("get_net_handle()");
        return [code, order];
    };

    /*** Blokly Message **/
    Blockly.Msg.en["SS_BLOCK_GET_NET_HANDLE"] = "get animal detection model";
    Blockly.Msg.zhhant["SS_BLOCK_GET_NET_HANDLE"] = "獲取動物檢測模型";


    /*****************************************************************************************************************************************/
    /***************************************************** End of Injecting New Blocks *****************************************************/
    /*****************************************************************************************************************************************/
}