console.log('动态制作加载新的积木')

function ss_blockly_inject(Blockly) {
    console.log('开给 blockly 注入新积木属性')


    /*****************************************************************************************************************************************/
    /***************************************************** Begin of Injecting New Blocks *****************************************************/
    /*****************************************************************************************************************************************/


    /************************************************************************************************************************************/

    /************************************************************************************************************************************/

    Blockly.defineBlocksWithJsonArray([{
        type: "ss_get_net_handle", // re-name the origianl block: ss_prim3_get_net_handle
        message0: "%{BKY_SS_BLOCK_GET_NET_HANDLE}",
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }]);

    /*** Blockly Python **/
    Blockly.Python['ss_get_net_handle'] = function (block) {
        var order = Blockly.Python.ORDER_ATOMIC;
        var code = Blockly.Python.format("get_net_handle()");
        return [code, order];
    };

    /*** Blokly Message **/
    Blockly.Msg.en["SS_BLOCK_GET_NET_HANDLE"] = "get animal detection model";
    Blockly.Msg.zhhant["SS_BLOCK_GET_NET_HANDLE"] = "獲取動物檢測模型";

    /************************************************************************************************************************************/

    Blockly.defineBlocksWithJsonArray([{
        type: "ss_sstorm_print_var", // to enable print(getDistance()), print is a default Python function
        message0: "%{BKY_SS_BLOCK_SSTORM_PRINT_VAR}",
        args0: [{
            type: "input_value",
            name: "MESSAGE",
            check: null // To enable a function to be assigned to print
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_OUTPUT}"
    }]);

    /*** Blockly Python **/
    Blockly.Python['ss_sstorm_print_var'] = function (block) {
        var argument0 = Blockly.Python.valueToCode(block, "MESSAGE", Blockly.Python.ORDER_NONE) || 'None';
        var code = "print(" + argument0 + ")";
        return code + "\n"
    };

    /*** Blokly Message **/
    Blockly.Msg.en["SS_BLOCK_SSTORM_PRINT_VAR"] = "print %1";
    Blockly.Msg.zhhant["SS_BLOCK_SSTORM_PRINT_VAR"] = "打印 %1";

    /************************************************************************************************************************************/

    Blockly.defineBlocksWithJsonArray([{
        type: "ss_sstorm_sleep", // sleep() is a default function in Python  
        message0: "%{BKY_SS_BLOCK_SSTORM_SLEEP}",
        args0: [{
            type: "input_value",
            name: "NUM",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }]);

    /*** Blockly Python **/
    Blockly.Python['ss_sstorm_sleep'] = function (block) {
        var argument0 = Blockly.Python.valueToCode(block, "NUM", Blockly.Python.ORDER_NONE) || 'None';
        var code = "sleep(" + argument0 + ")";
        return code + "\n"
    };

    /*** Blokly Message **/
    Blockly.Msg.en["SS_BLOCK_SSTORM_SLEEP"] = "sleep %1 seconds";
    Blockly.Msg.zhhant["SS_BLOCK_SSTORM_SLEEP"] = "停 %1 秒";

    /************************************************************************************************************************************/

    Blockly.defineBlocksWithJsonArray([{
        type: "ss_sstorm_speak", // to enable speak(''), to enable '' within (), pls pay attention to its xml 
        message0: "%{BKY_SS_BLOCK_SSTORM_SPEAK}",
        args0: [{
            type: "input_value",
            name: "MESSAGE",
            check: "String"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }]);

    /*** Blockly Python **/
    Blockly.Python['ss_sstorm_speak'] = function (block) {
        // speak('')
        var argument0 = Blockly.Python.valueToCode(block, 'MESSAGE', Blockly.Python.ORDER_ATOMIC) || 'None';
        var code = Blockly.Python.format("speak({0})", argument0);
        return code + "\n";
    };

    /*** Blokly Message **/
    Blockly.Msg.en["SS_BLOCK_SSTORM_SPEAK"] = "speak %1";
    Blockly.Msg.zhhant["SS_BLOCK_SSTORM_SPEAK"] = "講 %1";

    /************************************************************************************************************************************/

    Blockly.defineBlocksWithJsonArray([{
        type: "ss_sstorm_motor_run_time", // do not missing "ss_"
        message0: "%{BKY_SS_BLOCK_SSTORM_MOTOR_RUN_TIME}", // do not missing "BKY_SS_BLOCK_"
        args0: [{
            type: "field_dropdown", // this is fixed to create dropdown options
            name: "MOTOR", // name of the "Option" variable used in Blockly.Python
            options: [
                ["%{BKY_SS_BLOCK_SSTORM_DROPDOWN_MOTOR_A}", "motor_a"], // 1st col: for naming the block option 
                ["%{BKY_SS_BLOCK_SSTORM_DROPDOWN_MOTOR_B}", "motor_b"], // 2nd col: the real Python behind the block option
                ["%{BKY_SS_BLOCK_SSTORM_DROPDOWN_MOTOR_C}", "motor_c"],
                ["%{BKY_SS_BLOCK_SSTORM_DROPDOWN_MOTOR_D}", "motor_d"]
            ]
        }, {
            type: "input_value",
            name: "SPEED", // name of 2nd variable used in Blockly.Python
            check: "Number"
        }, {
            type: "input_value",
            name: "TIME", // name of 3rd variable used in Blockly.Python
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
        // To enable it to be assigned to other blocks
        /*output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
        */
    }]);

    /*** Blockly Python **/
    Blockly.Python['ss_sstorm_motor_run_time'] = function (block) {
        var argument0 = block.getFieldValue("MOTOR"); // fixed, execept the name "MOTOR"
        var argument1 = Blockly.Python.valueToCode(block, "SPEED", Blockly.Python.ORDER_ATOMIC) || "0";
        var argument2 = Blockly.Python.valueToCode(block, "TIME", Blockly.Python.ORDER_ATOMIC) || "0";
        var code = argument0 + ".run_time(" + argument1 + "," + argument2 + ")";
        return code + "\n";
    }; // return: e.g. motor_a.runtime(SPEED, TIME); motor_b.runtime(SPEED, TIME)

    //  To enable it to be assigned to other blocks
    /*Blockly.Python['ss_sstorm_motor_run_time'] = function (block) {
        var argument0 = block.getFieldValue("MOTOR"); // fixed, execept the name "MOTOR"
        var argument1 = Blockly.Python.valueToCode(block, "SPEED", Blockly.Python.ORDER_ATOMIC) || "0";
        var argument2 = Blockly.Python.valueToCode(block, "TIME", Blockly.Python.ORDER_ATOMIC) || "0";
        var code = argument0 + ".run_time(" + argument1 + "," + argument2 + ")";
        var order = Blockly.Python.ORDER_ATOMIC;
        return [code, order];
    };
    */



    /*** Blokly Message **/
    Blockly.Msg.en["SS_BLOCK_SSTORM_MOTOR_RUN_TIME"] = "move Motor %1 with a speed of %2 for %3 seconds";
    Blockly.Msg.zhhant["SS_BLOCK_SSTORM_MOTOR_RUN_TIME"] = "電機 %1 以 %2 的速度移動 %3 秒鐘";

    Blockly.Msg.en["SS_BLOCK_SSTORM_DROPDOWN_MOTOR_A"] = "A"; // name of the 1st option in block
    Blockly.Msg.zhhant["SS_BLOCK_SSTORM_DROPDOWN_MOTOR_A"] = "A";

    Blockly.Msg.en["SS_BLOCK_SSTORM_DROPDOWN_MOTOR_B"] = "B"; // name of the 2md option in block
    Blockly.Msg.zhhant["SS_BLOCK_SSTORM_DROPDOWN_MOTOR_B"] = "B";

    Blockly.Msg.en["SS_BLOCK_SSTORM_DROPDOWN_MOTOR_C"] = "C";
    Blockly.Msg.zhhant["SS_BLOCK_SSTORM_DROPDOWN_MOTOR_A"] = "C";

    Blockly.Msg.en["SS_BLOCK_SSTORM_DROPDOWN_MOTOR_D"] = "D";
    Blockly.Msg.zhhant["SS_BLOCK_SSTORM_DROPDOWN_MOTOR_B"] = "D";

    /*****************************************************************************************************************************************/
    /***************************************************** End of Injecting New Blocks *****************************************************/
    /*****************************************************************************************************************************************/
}