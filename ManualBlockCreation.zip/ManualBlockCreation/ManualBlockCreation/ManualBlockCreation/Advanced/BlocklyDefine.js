// Blockly Define Example

Blockly.defineBlocksWithJsonArray([{
    type: "ss_bailu_go",
    message0: "%{BKY_SS_BLOCK_BAILU_GO}",
    previousStatement: null,
    nextStatement: null,
    colour: "%{BKY_COLOR_OF_ACTION}"
}, {
    type: "ss_bailu_go2",
    message0: "%{BKY_SS_BLOCK_BAILU_GO2}",
    args0: [{
        type: "input_value",
        name: "POWER",
        check: "Number"
    }, {
        type: "input_value",
        name: "TIME",
        check: "Number"
    }],
    previousStatement: null,
    nextStatement: null,
    colour: "%{BKY_COLOR_OF_ACTION}"
}, {
    type: "ss_bailu_go3",
    message0: "%{BKY_SS_BLOCK_BAILU_GO3}",
    args0: [{
        type: "input_value",
        name: "POWER1",
        check: "Number"
    }, {
        type: "input_value",
        name: "POWER2",
        check: "Number"
    }, {
        type: "input_value",
        name: "TIME",
        check: "Number"
    }],
    previousStatement: null,
    nextStatement: null,
    colour: "%{BKY_COLOR_OF_ACTION}"
}, {
    type: "ss_bailu_set",
    message0: "%{BKY_SS_BLOCK_BAILU_SET}",
    args0: [{
        type: "input_value",
        name: "X",
        check: "Number"
    }, {
        type: "input_value",
        name: "Y",
        check: "Number"
    }],
    previousStatement: null,
    nextStatement: null,
    colour: "%{BKY_COLOR_OF_ACTION}"
}, {
    type: "ss_bailu_getdeviation",
    message0: "%{BKY_SS_BLOCK_BAILU_DEVIATION}",
    output: "Number",
    outputShape: Blockly.OUTPUT_SHAPE_ROUND,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}, {
    type: "ss_bailu_refresh",
    message0: "%{BKY_SS_BLOCK_BAILU_REFRESH}",
    previousStatement: null,
    nextStatement: null,
    colour: "%{BKY_COLOR_OF_ACTION}"
}, {
    type: "ss_bailu_getcolor",
    message0: "%{BKY_SS_BLOCK_BAILU_COLORS}",
    output: "Array",
    outputShape: Blockly.OUTPUT_SHAPE_ROUND,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}, {
    type: "ss_bailu_getcolor_i",
    message0: "%{BKY_SS_BLOCK_BAILU_COLORS_I}",
    args0: [{
        type: "field_dropdown",
        name: "INDEX",
        options: [
            ["1", "0"],
            ["2", "1"],
            ["3", "2"],
            ["4", "3"]
        ]
    }],
    output: "String",
    outputShape: Blockly.OUTPUT_SHAPE_ROUND,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}, {
    type: "ss_bailu_colors_define",
    message0: "%1",
    args0: [{
        type: "field_dropdown",
        name: "INDEX",
        options: [
            ["%{BKY_SS_BLOCK_BAILU_COLORS_DEFINE_RED}", "red"],
            ["%{BKY_SS_BLOCK_BAILU_COLORS_DEFINE_GREEN}", "green"],
            ["%{BKY_SS_BLOCK_BAILU_COLORS_DEFINE_BLUE}", "blue"]
        ]
    }],
    output: "String",
    outputShape: Blockly.OUTPUT_SHAPE_ROUND,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}, {
    type: "ss_bailu_isfail",
    message0: "%{BKY_SS_BLOCK_BAILU_ISFAIL}",
    output: "Boolean",
    outputShape: Blockly.OUTPUT_SHAPE_ROUND,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}, {
    type: "ss_bailu_getdistance",
    message0: "%{BKY_SS_BLOCK_BAILU_DISTANCES}",
    output: "Array",
    outputShape: Blockly.OUTPUT_SHAPE_ROUND,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}, {
    type: "ss_bailu_getdistance_i",
    message0: "%{BKY_SS_BLOCK_BAILU_DISTANCES_I}",
    args0: [{
        type: "field_dropdown",
        name: "INDEX",
        options: [
            ["%{BKY_SS_BLOCK_BAILU_DISTANCES_I_LF}", "0"],
            ["%{BKY_SS_BLOCK_BAILU_DISTANCES_I_RF}", "1"],
            ["%{BKY_SS_BLOCK_BAILU_DISTANCES_I_F}",
                "2"
            ],
            ["%{BKY_SS_BLOCK_BAILU_DISTANCES_I_B}", "3"]
        ]
    }],
    output: "Number",
    outputShape: Blockly.OUTPUT_SHAPE_ROUND,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}, {
    type: "ss_bailu_getintensity",
    message0: "%{BKY_SS_BLOCK_BAILU_INTENSITIES}",
    output: "Array",
    outputShape: Blockly.OUTPUT_SHAPE_ROUND,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}, {
    type: "ss_bailu_getintensity_i",
    message0: "%{BKY_SS_BLOCK_BAILU_INTENSITIES_I}",
    args0: [{
        type: "field_dropdown",
        name: "INDEX",
        options: [
            ["1", "0"],
            ["2", "1"],
            ["3", "2"],
            ["4", "3"]
        ]
    }],
    output: "Number",
    outputShape: Blockly.OUTPUT_SHAPE_ROUND,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}]);
Blockly.defineBlocksWithJsonArray([{
        type: "ss_pocket_go",
        message0: "%{BKY_SS_BLOCK_POCKET_GO}",
        args0: [{
            type: "input_value",
            name: "SPEED",
            check: "Number"
        }, {
            type: "input_value",
            name: "TIME",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_pocket_go2",
        message0: "%{BKY_SS_BLOCK_POCKET_GO2}",
        args0: [{
            type: "input_value",
            name: "LSPEED",
            check: "Number"
        }, {
            type: "input_value",
            name: "RSPEED",
            check: "Number"
        }, {
            type: "input_value",
            name: "TIME",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_pocket_turn",
        message0: "%{BKY_SS_BLOCK_POCKET_TURN}",
        args0: [{
            type: "input_value",
            name: "DEGREE",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_pocket_setrgb",
        message0: "%{BKY_SS_BLOCK_POCKET_SETRGB}",
        args0: [{
            type: "input_value",
            name: "RED",
            check: "Number"
        }, {
            type: "input_value",
            name: "GREEN",
            check: "Number"
        }, {
            type: "input_value",
            name: "BLUE",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_pocket_distance",
        message0: "%{BKY_SS_BLOCK_POCKET_DISTANCE}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_FL}", "0"],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_FR}", "1"]
            ]
        }],
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_distance_detect",
        message0: "%{BKY_SS_BLOCK_POCKET_DISTANCE_DETECT}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_FL}",
                    "0"
                ],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_FR}", "1"]
            ]
        }, {
            type: "field_dropdown",
            name: "OP",
            options: [
                [">", "GREATER"],
                ["<", "LESS"],
                ["=", "EQUAL"],
                ["!=", "NOTEQUAL"]
            ]
        }, {
            type: "input_value",
            name: "NUM",
            check: "Number"
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_colorsensor",
        message0: "%{BKY_SS_BLOCK_POCKET_COLORSENSOR}",
        args0: [{
            type: "field_dropdown",
            name: "OPTIONS",
            options: [
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_R}", "0"],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_G}",
                    "1"
                ],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_B}", "2"],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_C}", "3"]
            ]
        }],
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_detecs_black",
        message0: "%{BKY_SS_BLOCK_POCKET_DETECTS_BLACK}",
        args0: [{
            type: "input_value",
            name: "THRESHOLD",
            check: "Number"
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_detecs_white",
        message0: "%{BKY_SS_BLOCK_POCKET_DETECTS_WHITE}",
        args0: [{
            type: "input_value",
            name: "THRESHOLD",
            check: "Number"
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_detects_color",
        message0: "%{BKY_SS_BLOCK_POCKET_DETECTS_COLOR}",
        args0: [{
            type: "field_dropdown",
            name: "COLOR",
            options: [
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_RED}", "red"],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_GREEN}", "green"],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_BLUE}", "blue"]
            ]
        }, {
            type: "input_value",
            name: "THRESHOLD1",
            check: "Number"
        }, {
            type: "input_value",
            name: "THRESHOLD2",
            check: "Number"
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_light_tracking",
        message0: "%{BKY_SS_BLOCK_POCKET_LIGHTTRACK}",
        args0: [{
            type: "input_value",
            name: "WHITE",
            check: "Number"
        }, {
            type: "input_value",
            name: "BLACK",
            check: "Number"
        }, {
            type: "input_value",
            name: "WEIGHT",
            check: "Array"
        }, {
            type: "input_value",
            name: "SPEED",
            check: "Number"
        }, {
            type: "input_value",
            name: "TIME",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    },
    {
        type: "ss_pocket_light_withdiff",
        message0: "%{BKY_SS_BLOCK_POCKET_LIGHTTRACKWITHDIFF}",
        args0: [{
            type: "input_value",
            name: "WHITE",
            check: "Number"
        }, {
            type: "input_value",
            name: "BLACK",
            check: "Number"
        }, {
            type: "input_value",
            name: "WEIGHT",
            check: "Array"
        }, {
            type: "input_value",
            name: "SPEED",
            check: "Number"
        }, {
            type: "input_value",
            name: "P",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_pocket_getaverage_distance",
        message0: "%{BKY_SS_BLOCK_POCKET_AVERAGE_DISTANCE}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_FL}", "0"],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_FR}", "1"]
            ]
        }],
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_front_distance",
        message0: "%{BKY_SS_BLOCK_POCKET_FRONT_DISTANCE}",
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_get_turn_angle",
        message0: "%{BKY_SS_BLOCK_POCKET_GETTURNANGLE}",
        args0: [{
                type: "input_value",
                name: "DISTANCE",
                check: "Number"
            },
            {
                type: "input_value",
                name: "RATIO",
                check: "Number"
            }
        ],
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_pirate_treasure",
        message0: "%{BKY_SS_BLOCK_POCKET_PIRATETREASURE}",
        args0: [{
            type: "input_value",
            name: "DISTANCE",
            check: "Number"
        }, {
            type: "input_value",
            name: "ANGLE",
            check: "Number"
        }, {
            type: "input_value",
            name: "TIME",
            check: "Number"
        }, {
            type: "input_value",
            name: "SPEED",
            check: "Number"
        }, {
            type: "field_dropdown",
            name: "COLOR",
            options: [
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_RED}",
                    "red"
                ],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_GREEN}", "green"],
                ["%{BKY_SS_BLOCK_POCKET_DROPDOWN_BLUE}", "blue"]
            ]
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_pocket_getintensity",
        message0: "%{BKY_SS_BLOCK_POCKET_GET_INTENSITY}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["0", "0"],
                ["1", "1"],
                ["2", "2"],
                ["3", "3"],
                ["4", "4"]
            ]
        }],
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_getintensity_all",
        message0: "%{BKY_SS_BLOCK_POCKET_GET_INTENSITY_ALL}",
        output: "Array",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_getdistance_all",
        message0: "%{BKY_SS_BLOCK_POCKET_GET_DISTANCE_ALL}",
        output: "Array",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_getcolor_all",
        message0: "%{BKY_SS_BLOCK_POCKET_GET_COLOR_ALL}",
        output: "Array",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_getlrspeed_all",
        message0: "%{BKY_SS_BLOCK_POCKET_GET_LR_SPEED_ALL}",
        output: "Array",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_get_turn_angle_2",
        message0: "%{BKY_SS_BLOCK_POCKET_GETTURNANGLE_2}",
        args0: [{
            type: "input_value",
            name: "START",
            check: "Number"
        }, {
            type: "input_value",
            name: "P",
            check: "Number"
        }],
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_get_min_distance",
        message0: "%{BKY_SS_BLOCK_POCKET_GETMINDISTANCE}",
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_intensity_detect",
        message0: "%{BKY_SS_BLOCK_POCKET_INTENSITY_DETECT}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["0", "0"],
                ["1", "1"],
                ["2", "2"],
                ["3", "3"],
                ["4", "4"]
            ]
        }, {
            type: "field_dropdown",
            name: "OP",
            options: [
                [">", "GREATER"],
                ["<", "LESS"],
                ["=", "EQUAL"],
                ["!=", "NOTEQUAL"]
            ]
        }, {
            type: "input_value",
            name: "NUM",
            check: "Number"
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_pocket_lightwithPID",
        message0: "%{BKY_SS_BLOCK_POCKET_LIGHTTRACKWITHPID}",
        args0: [{
            type: "input_value",
            name: "WHITE",
            check: "Number"
        }, {
            type: "input_value",
            name: "BLACK",
            check: "Number"
        }, {
            type: "input_value",
            name: "WEIGHT",
            check: "Array"
        }, {
            type: "input_value",
            name: "SPEED",
            check: "Number"
        }, {
            type: "input_value",
            name: "TIME",
            check: "Number"
        }, {
            type: "input_value",
            name: "P",
            check: "Number"
        }, {
            type: "input_value",
            name: "D",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }
]);
Blockly.defineBlocksWithJsonArray([{
    type: "ss_unity_forward",
    message0: "%{BKY_SS_BLOCK_UNITY_FORWARD}",
    previousStatement: null,
    nextStatement: null,
    colour: "%{BKY_COLOR_OF_ACTION}"
}, {
    type: "ss_unity_collect",
    message0: "%{BKY_SS_BLOCK_UNITY_COLLECT}",
    previousStatement: null,
    nextStatement: null,
    colour: "%{BKY_COLOR_OF_ACTION}"
}, {
    type: "ss_unity_right",
    message0: "%{BKY_SS_BLOCK_UNITY_RIGHT}",
    previousStatement: null,
    nextStatement: null,
    colour: "%{BKY_COLOR_OF_ACTION}"
}, {
    type: "ss_unity_left",
    message0: "%{BKY_SS_BLOCK_UNITY_LEFT}",
    previousStatement: null,
    nextStatement: null,
    colour: "%{BKY_COLOR_OF_ACTION}"
}, {
    type: "ss_unity_hasobstacle",
    message0: "%{BKY_SS_BLOCK_UNITY_HASOBSTACLE}",
    args0: [{
        type: "field_dropdown",
        name: "SIDE",
        options: [
            ["%{BKY_SS_BLOCK_UNITY_HASOBSTACLE_1}", "LEFT"],
            ["%{BKY_SS_BLOCK_UNITY_HASOBSTACLE_2}", "FRONT"],
            ["%{BKY_SS_BLOCK_UNITY_HASOBSTACLE_3}", "RIGHT"]
        ]
    }],
    output: "Boolean",
    outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}, {
    type: "ss_unity_onwhat",
    message0: "%{BKY_SS_BLOCK_UNITY_ONWHAT}",
    args0: [{
        type: "field_dropdown",
        name: "WHAT",
        options: [
            ["%{BKY_SS_BLOCK_UNITY_ONWHAT_1}", "ENERGY"],
            ["%{BKY_SS_BLOCK_UNITY_ONWHAT_2}", "FINISH"]
        ]
    }],
    output: "Boolean",
    outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
    colour: "%{BKY_COLOR_OF_DETECTION}"
}]);
Blockly.defineBlocksWithJsonArray([{
        type: "ss_vcar_go",
        message0: "%{BKY_SS_BLOCK_VCAR_GO}",
        args0: [{
            type: "input_value",
            name: "LEFT",
            check: "Number"
        }, {
            type: "input_value",
            name: "RIGHT",
            check: "Number"
        }, {
            type: "input_value",
            name: "FRAME",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_vcar_go2",
        message0: "%{BKY_SS_BLOCK_VCAR_GO2}",
        args0: [{
            type: "input_value",
            name: "LEFT",
            check: "Number"
        }, {
            type: "input_value",
            name: "RIGHT",
            check: "Number"
        }, {
            type: "input_value",
            name: "TIME",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_vcar_set",
        message0: "%{BKY_SS_BLOCK_VCAR_SET}",
        args0: [{
            type: "input_value",
            name: "X",
            check: "Number"
        }, {
            type: "input_value",
            name: "Y",
            check: "Number"
        }, {
            type: "input_value",
            name: "DEVIATION",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_vcar_refresh",
        message0: "%{BKY_SS_BLOCK_VCAR_REFRESH}",
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    },
    {
        type: "ss_vcar_runwithPID",
        message0: "%{BKY_SS_BLOCK_VCAR_RUNWITHPID}",
        args0: [{
            type: "input_value",
            name: "KP",
            check: "Number"
        }, {
            type: "input_value",
            name: "KD",
            check: "Number"
        }, {
            type: "input_value",
            name: "V0",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_ACTION}"
    }, {
        type: "ss_vcar_deviation",
        message0: "%{BKY_SS_BLOCK_VCAR_DEVIATION}",
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_vcar_clockwise_degree",
        message0: "%{BKY_SS_BLOCK_VCAR_CLOCKWISE_DEGREE}",
        args0: [{
            type: "input_value",
            name: "DEGREE",
            check: "Number"
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_vcar_anticlockwise_degree",
        message0: "%{BKY_SS_BLOCK_VCAR_ANTICLOCKWISE_DEGREE}",
        args0: [{
            type: "input_value",
            name: "DEGREE",
            check: "Number"
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_vcar_settarget",
        message0: "%{BKY_SS_BLOCK_VCAR_SET_TARGET}",
        args0: [{
            type: "input_value",
            name: "NUM",
            check: "Number"
        }],
        previousStatement: null,
        nextStatement: null,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_vcar_distance",
        message0: "%{BKY_SS_BLOCK_VCAR_DISTANCE}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_FL}", "0"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_FR}", "1"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_FRONT}", "2"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_REAR}", "3"]
            ]
        }],
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_vcar_distance_detect",
        message0: "%{BKY_SS_BLOCK_VCAR_DISTANCE_DETECT}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_FL}", "0"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_FR}", "1"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_FRONT}", "2"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_REAR}", "3"]
            ]
        }, {
            type: "field_dropdown",
            name: "OP",
            options: [
                [">", "GREATER"],
                ["<", "LESS"],
                ["=", "EQUAL"],
                ["!=", "NOTEQUAL"]
            ]
        }, {
            type: "input_value",
            name: "NUM",
            check: "Number"
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    },
    {
        type: "ss_vcar_color_detect",
        message0: "%{BKY_SS_BLOCK_VCAR_COLOR_DETECT}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["1", "0"],
                ["2", "1"],
                ["3", "2"],
                ["4", "3"]
            ]
        }, {
            type: "field_dropdown",
            name: "OP",
            options: [
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_HAS}", "NOTLESS"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_HASNOT}", "LESS"]
            ]
        }, {
            type: "field_dropdown",
            name: "COLOR",
            options: [
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_RED}", "0"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_GREEN}", "1"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_BLUE}", "2"]
            ]
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_vcar_intensity_detect",
        message0: "%{BKY_SS_BLOCK_VCAR_INTENSITY_DETECT}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["1", "0"],
                ["2", "1"],
                ["3", "2"],
                ["4", "3"]
            ]
        }, {
            type: "field_dropdown",
            name: "OP",
            options: [
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_HAS}", "NOTLESS"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_HASNOT}", "LESS"]
            ]
        }],
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_vcar_getlineloc",
        message0: "%{BKY_SS_BLOCK_VCAR_GETLINELOC}",
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_vcar_precise_distance",
        message0: "%{BKY_SS_BLOCK_VCAR_PRECISE_DISTANCE}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_FL}", "0"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_FR}", "1"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_FRONT}", "2"],
                ["%{BKY_SS_BLOCK_VCAR_DROPDOWN_REAR}", "3"]
            ]
        }],
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    },
    {
        type: "ss_vcar_getintensity",
        message0: "%{BKY_SS_BLOCK_VCAR_GETINTENSITY}",
        args0: [{
            type: "field_dropdown",
            name: "INDEX",
            options: [
                ["1", "0"],
                ["2", "1"],
                ["3", "2"],
                ["4", "3"]
            ]
        }],
        output: "Number",
        outputShape: Blockly.OUTPUT_SHAPE_ROUND,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }, {
        type: "ss_vcar_incurrenttask",
        message0: "%{BKY_SS_BLOCK_VCAR_INCURRENTTASK}",
        output: "Boolean",
        outputShape: Blockly.OUTPUT_SHAPE_HEXAGONAL,
        colour: "%{BKY_COLOR_OF_DETECTION}"
    }
]);